# Online shopping cart
class ItemToPurchase:
    def __init__(self):
        self.item_name = "none"
        self.item_price = 0
        self.item_quantity = 0
        self.item_description = "none"
    
    def print_item_cost(self):
        total_cost = self.item_price * self.item_quantity
        print(f"{self.item_name} {self.item_quantity} @ ${self.item_price} = ${total_cost}")
    
    def print_item_description(self):
        print(f"{self.item_name}: {self.item_description}")


class ShoppingCart:
    def __init__(self, customer_name, current_date):
        self.customer_name = customer_name
        self.current_date = current_date
        self.cart_items = []
    
    def add_item(self, item):
        self.cart_items.append(item)
    
    def remove_item(self, item_name):
        for item in self.cart_items:
            if item.item_name == item_name:
                self.cart_items.remove(item)
                return
        print("Item not found in cart. Nothing removed.")
    
    def modify_item(self, item):
        for i, cart_item in enumerate(self.cart_items):
            if cart_item.item_name == item.item_name:
                item.item_price = cart_item.item_price  # Retrieve the item price from the cart
                self.cart_items[i] = item
                return
        print("Item not found in cart. Nothing modified.")
    
    def get_num_items_in_cart(self):
        total_quantity = 0
        for item in self.cart_items:
            total_quantity += item.item_quantity
        return total_quantity
    
    def get_cost_of_cart(self):
        total_cost = 0
        for item in self.cart_items:
            total_cost += item.item_price * item.item_quantity
        return total_cost
    
    def print_total(self):
        print(f"{self.customer_name}'s Shopping Cart - {self.current_date}")
        print("Number of Items:", self.get_num_items_in_cart())
        print()
        if len(self.cart_items) == 0:
            print("SHOPPING CART IS EMPTY")
        else:
            for item in self.cart_items:
                item.print_item_cost()
        print()
        print("Total:","$" + str(self.get_cost_of_cart()))
    
    def print_descriptions(self):
        print(f"{self.customer_name}'s Shopping Cart - {self.current_date}")
        print()
        print("Item Descriptions")
        for item in self.cart_items:
            item.print_item_description()
        


def print_menu():
    print("\nMENU")
    print("a - Add item to cart")
    print("r - Remove item from cart")
    print("c - Change item quantity")
    print("i - Output items' descriptions")
    print("o - Output shopping cart")
    print("q - Quit")



def execute_menu(choice, cart):
    if choice == "a":
        print("\nADD ITEM TO CART")
        item = ItemToPurchase()
        item.item_name = input("Enter the item name:\n")
        item.item_description = input("Enter the item description:\n")
        item.item_price = int(input("Enter the item price:\n"))
        item.item_quantity = int(input("Enter the item quantity:\n"))
        cart.add_item(item)
        print_menu()
        return True
    elif choice == "r":
        print("\nREMOVE ITEM FROM CART")
        item_name = input("Enter name of item to remove:\n")
        cart.remove_item(item_name)
        print_menu()
        return True
    elif choice == "c":
        print("\nCHANGE ITEM QUANTITY")
        item_name = input("Enter the item name:\n")
        new_quantity = int(input("Enter the new quantity:\n"))
        item = ItemToPurchase()
        item.item_name = item_name
        item.item_quantity = new_quantity
        cart.modify_item(item)
        print_menu()
        return True
    elif choice == "i":
        print("\nOUTPUT ITEMS' DESCRIPTIONS")
        cart.print_descriptions()
        print_menu()
        return True
    elif choice == "o":
        print("\nOUTPUT SHOPPING CART")
        cart.print_total()
        print_menu()
        return True
    elif choice == "q":
        return False
    else:
        return True


if __name__ == "__main__":
    customer_name = input("Enter customer's name:\n")
    current_date = input("Enter today's date:\n")

    print("\nCustomer name:", customer_name)
    print("Today's date:", current_date)

    shopping_cart = ShoppingCart(customer_name, current_date)
    print_menu()

    while True:
        choice = input("\nChoose an option:")
        if not execute_menu(choice, shopping_cart):
            print()
            break
